import { z } from "zod";

// User schema
export const userSchema = z.object({
  uid: z.string(),
  name: z.string(),
  email: z.string().email(),
  role: z.enum(["admin", "volunteer"]),
  phone: z.string().optional(),
  joinedAt: z.string(),
});

export type User = z.infer<typeof userSchema>;

export const insertUserSchema = userSchema.omit({ uid: true, joinedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;

// Event schema
export const eventSchema = z.object({
  id: z.string(),
  title: z.string(),
  date: z.string(),
  time: z.string(),
  venue: z.string(),
  address: z.string(),
  lat: z.number().optional(),
  lng: z.number().optional(),
  description: z.string(),
  category: z.string(),
  createdBy: z.string(),
  createdAt: z.string(),
});

export type Event = z.infer<typeof eventSchema>;

export const insertEventSchema = eventSchema.omit({ id: true, createdAt: true });
export type InsertEvent = z.infer<typeof insertEventSchema>;

// Registration schema
export const registrationSchema = z.object({
  id: z.string(),
  eventId: z.string(),
  userId: z.string().optional(),
  name: z.string(),
  contact: z.string(),
  role: z.string(),
  status: z.string().default("pending"),
  timestamp: z.string(),
});

export type Registration = z.infer<typeof registrationSchema>;

export const insertRegistrationSchema = registrationSchema.omit({ id: true, timestamp: true });
export type InsertRegistration = z.infer<typeof insertRegistrationSchema>;

// Donation schema
export const donationSchema = z.object({
  id: z.string(),
  donorName: z.string(),
  email: z.string().email(),
  phone: z.string().optional(),
  amount: z.number(),
  date: z.string(),
  purpose: z.string(),
  note: z.string().optional(),
});

export type Donation = z.infer<typeof donationSchema>;

export const insertDonationSchema = donationSchema.omit({ id: true, date: true });
export type InsertDonation = z.infer<typeof insertDonationSchema>;

// Seva Log schema
export const sevaLogSchema = z.object({
  id: z.string(),
  userId: z.string(),
  eventId: z.string(),
  hours: z.number(),
  role: z.string(),
  date: z.string(),
  note: z.string().optional(),
});

export type SevaLog = z.infer<typeof sevaLogSchema>;

export const insertSevaLogSchema = sevaLogSchema.omit({ id: true });
export type InsertSevaLog = z.infer<typeof insertSevaLogSchema>;

// Book schema
export const bookSchema = z.object({
  id: z.string(),
  title: z.string(),
  authors: z.array(z.string()),
  language: z.string(),
  categories: z.array(z.string()),
  storagePath: z.string(),
  description: z.string().optional(),
  uploadedBy: z.string(),
  createdAt: z.string(),
  downloadUrl: z.string().optional(),
});

export type Book = z.infer<typeof bookSchema>;

export const insertBookSchema = bookSchema.omit({ id: true, createdAt: true, downloadUrl: true });
export type InsertBook = z.infer<typeof insertBookSchema>;

// Verse schema
export const verseSchema = z.object({
  id: z.string(),
  verseTextEn: z.string(),
  verseTextNe: z.string().optional(),
  verseTextHi: z.string().optional(),
  source: z.string(),
  chapter: z.number().optional(),
  verse: z.number().optional(),
});

export type Verse = z.infer<typeof verseSchema>;

export const insertVerseSchema = verseSchema.omit({ id: true });
export type InsertVerse = z.infer<typeof insertVerseSchema>;

// Translation request schema
export const translationRequestSchema = z.object({
  text: z.string(),
  sourceLang: z.string().default("en"),
  targetLang: z.string(),
});

export type TranslationRequest = z.infer<typeof translationRequestSchema>;

// Language codes
export const languages = {
  en: "English",
  hi: "हिन्दी (Hindi)",
  ne: "नेपाली (Nepali)",
} as const;

export type LanguageCode = keyof typeof languages;
