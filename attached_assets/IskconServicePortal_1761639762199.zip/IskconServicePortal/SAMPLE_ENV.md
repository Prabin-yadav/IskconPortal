# Sample Environment Variables

This file shows example values for the environment variables needed to run the ISKCON Digital Service Portal.

## Firebase Configuration (Frontend)

These should be set in your Replit Secrets or `.env` file:

```
VITE_FIREBASE_API_KEY=AIzaSyBxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789012
VITE_FIREBASE_APP_ID=1:123456789012:web:abcdef1234567890
```

## Backend Configuration

```
TRANSLATE_URL=https://libretranslate.com/translate
```

## How to Get Firebase Credentials

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select existing one
3. Click on "Add app" (web icon `</>`)
4. Register your app
5. Copy the config values to your environment variables

## Firebase Setup Required

After creating your Firebase project:

1. **Enable Authentication:**
   - Go to Authentication → Sign-in method
   - Enable "Email/Password"

2. **Create Firestore Database:**
   - Go to Firestore Database
   - Click "Create database"
   - Start in "test mode" for development
   - Select a location

3. **Enable Storage:**
   - Go to Storage
   - Click "Get started"
   - Start in "test mode" for development

## Optional: Google Cloud Translation

For production translation with better quality:

```
GOOGLE_APPLICATION_CREDENTIALS=./path/to/service-account-key.json
GOOGLE_PROJECT_ID=your-google-cloud-project-id
```

1. Create a Google Cloud project
2. Enable Cloud Translation API
3. Create a service account
4. Download the JSON key file
5. Set the path in GOOGLE_APPLICATION_CREDENTIALS

## LibreTranslate (Free Alternative)

The default `TRANSLATE_URL` points to LibreTranslate's public instance, which is free but rate-limited.

For better performance, you can:
- Host your own LibreTranslate instance
- Use a paid LibreTranslate API
- Switch to Google Cloud Translation

## Running the Application

1. Set all required environment variables
2. Install dependencies: `npm install`
3. Start the application: `npm run dev`
4. Access at: `http://localhost:5000`
