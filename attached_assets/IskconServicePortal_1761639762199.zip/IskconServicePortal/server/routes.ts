import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(express.json());

  // Translation proxy endpoint
  app.post('/api/translate', async (req, res) => {
    try {
      const { text, sourceLang = 'en', targetLang = 'hi' } = req.body;

      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }

      const translateUrl = process.env.TRANSLATE_URL || 'https://libretranslate.com/translate';

      const response = await fetch(translateUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          q: text,
          source: sourceLang,
          target: targetLang,
          format: 'text',
        }),
      });

      if (!response.ok) {
        throw new Error(`Translation API error: ${response.statusText}`);
      }

      const data = await response.json();
      res.json({ translatedText: data.translatedText });
    } catch (error: any) {
      console.error('Translation error:', error);
      res.status(500).json({ error: error.message || 'Translation failed' });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  const httpServer = createServer(app);

  return httpServer;
}
