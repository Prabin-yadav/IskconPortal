# ISKCON Digital Service Portal - Design Guidelines

## Design Approach

**Selected Approach:** Custom Devotional Design System
This portal requires a unique devotional aesthetic that balances traditional religious reverence with modern web usability. Drawing inspiration from spiritual/cultural platforms while maintaining accessibility and functionality.

**Core Principle:** "Modern devotion through design" - combining sacred aesthetics with contemporary UX patterns to create a welcoming, respectful digital space for ISKCON community.

---

## Typography System

**Font Families:**
- **Primary (Headings):** Poppins (weights: 400, 600, 700) - modern, clean, approachable
- **Secondary (Body):** Noto Sans (weights: 300, 400, 500) - excellent multilingual support for English, Hindi, Nepali, Devanagari script
- **Accent (Sanskrit/Devotional):** Noto Serif Devanagari for verses and sacred text

**Type Scale:**
- Hero/Main Headings: text-5xl to text-6xl (Poppins 700)
- Section Headings: text-3xl to text-4xl (Poppins 600)
- Subsection Headings: text-xl to text-2xl (Poppins 600)
- Body Text: text-base to text-lg (Noto Sans 400)
- Scripture/Verse Text: text-lg to text-xl (Noto Serif Devanagari 400) - generous line height 1.8
- Small Text/Captions: text-sm (Noto Sans 300)

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Micro spacing (within components): p-2, gap-2, mb-4
- Component spacing: p-4, p-6, gap-6
- Section spacing: py-12, py-16, py-20, py-24
- Large spacing: mt-20, mb-24

**Container Strategy:**
- Full-width sections: w-full with max-w-7xl mx-auto px-6
- Content sections: max-w-6xl mx-auto
- Reading content (scriptures): max-w-4xl mx-auto
- Cards/Components: max-w-sm to max-w-md

**Grid Systems:**
- Event cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Feature tiles (homepage): grid-cols-1 md:grid-cols-3 gap-8
- Library books: grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6
- Admin dashboard stats: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4

---

## Component Library

### Navigation
**Header:**
- Fixed/sticky top navigation with subtle shadow
- Logo + portal name on left
- Main navigation: Events, Library, Donate, Seva (center/right)
- Authentication buttons + language selector + theme toggle (far right)
- Mobile: Hamburger menu with slide-out drawer
- Background: Cream (#fff8ec) with subtle border-b in maroon

**Footer:**
- Three-column layout: About ISKCON, Quick Links, Contact/Social
- Newsletter signup section
- Language selector
- Copyright and devotional tagline
- Background: Deep maroon (#7a1f2f) with cream text

### Cards & Content Blocks

**Event Cards:**
- Elevated card with rounded-lg border
- Event image at top (aspect-ratio-16/9)
- Category badge (saffron background)
- Event title (text-xl Poppins 600)
- Date/time with icon, venue with location icon
- Description snippet (2 lines)
- "View Details" and "Register as Volunteer" buttons
- Hover: subtle lift (shadow-md to shadow-lg transition)

**Book Cards (Library):**
- Vertical card layout with book cover placeholder/image
- Title (text-lg Poppins 600)
- Author and language badges
- Category tags
- Download and "Read Online" buttons
- Minimal border with hover shadow effect

**Donation Cards:**
- Purpose-based donation cards with icon
- Suggested amounts as button chips
- Custom amount input
- "Donate with Love" CTA button (saffron)
- Trust indicators (secure, tax-deductible)

**Seva Log Cards:**
- Timeline-style cards showing date, hours, role
- Color-coded by seva type
- Admin view: expandable details with volunteer info

### Forms

**Input Fields:**
- Labels: text-sm Poppins 600 uppercase tracking-wide mb-2
- Inputs: rounded-lg border-2 px-4 py-3 focus:border-saffron transition
- Placeholder text in muted cream-dark
- Helper text below in text-sm
- Error states: border-red with icon and message

**Buttons:**
- Primary (CTA): Saffron (#f39c12) with white text, rounded-lg, px-6 py-3
- Secondary: Deep maroon outline with maroon text
- Ghost: Transparent with hover background
- Icon buttons for actions (edit, delete, download)
- All buttons: font-medium, transition-all, active:scale-95

### Data Display

**Statistics Dashboard:**
- Large number cards with icon, label, and trend indicator
- Background: subtle cream gradient
- Border-left accent in saffron or maroon
- Chart.js visualizations with theme-matched colors

**Tables:**
- Striped rows with alternating cream backgrounds
- Header row: Deep maroon background with cream text
- Borders: subtle, not heavy
- Action buttons in row: icon-only with tooltips
- Export CSV button at top-right

**PDF Reader:**
- Two-column layout on desktop: navigation sidebar (left) + viewer (right)
- Sidebar: Thumbnail previews, page list, bookmarks
- Viewer: Canvas with text layer overlay
- Controls: Zoom, page navigation, download, translate
- Translate overlay: Semi-transparent cream background with translated text
- Toggle buttons: "Original" | "Translated" | "Side-by-Side"

### Overlays & Modals

**Modal Dialogs:**
- Centered overlay with backdrop (bg-black/50)
- Content card: rounded-xl, max-w-2xl, p-8
- Close button (X) top-right
- Actions: Button row at bottom (Cancel + Primary action)

**Toast Notifications:**
- Top-right corner
- Color-coded: success (green), error (red), info (blue), devotional (saffron)
- Auto-dismiss with progress bar
- Icon + message + close button

---

## Page-Specific Layouts

### Homepage
- **Hero Section:** (h-screen) - Large devotional background image (temple/deity) with semi-transparent overlay
  - Om symbol or ISKCON logo watermark (subtle, large)
  - Main heading: "ISKCON Digital Service Portal — seva, śraddhā, śikṣā"
  - Two-line invocation: "Om ādi-puruṣāya namaḥ — Welcome. May all work here be for devotional service."
  - CTA buttons: "Explore Events" + "Join as Volunteer" (with blurred backgrounds)
  
- **Three Main Service Tiles:** (py-20)
  - Grid: 3 columns on desktop, stack on mobile
  - Each tile: Large icon, title, description, "Learn More" link
  - Tiles: Events & Volunteers | Donations & Seva | Digital Library
  
- **Daily Gita Verse Widget:** (py-16 bg-cream)
  - Centered card with decorative border
  - Verse text in Devanagari + selected language
  - Language toggle buttons
  - Rotating/random verse on page load
  
- **Statistics Section:** (py-16)
  - Four-column stats: Total Events, Active Volunteers, Books Available, Seva Hours
  - Animated count-up effect

### Events Page
- **Filter Bar:** Top horizontal bar with date range, category dropdown, search
- **Event Grid:** Card layout as described above
- **Event Detail Page:** 
  - Hero image (event photo)
  - Breadcrumb navigation
  - Two-column: Left (event details, schedule, description) | Right (Google Maps embed, registration form)
  - Volunteer registration form card with fields and "Submit Registration" button

### Library Page
- **Search + Filters:** Top bar with search input, language filter, category filter
- **Book Grid:** Responsive grid of book cards
- **Book Detail/Reader:**
  - PDF.js viewer with sidebar navigation
  - Translate controls: Source language selector, Target language selector, "Translate Page" button
  - Translation overlay with options
  - Download and share buttons

### Donate Page
- **Hero Section:** Devotional message about giving
- **Donation Form:** Center-aligned card
  - Donor info fields
  - Purpose selection (dropdown or chips)
  - Amount input with suggested amounts
  - "Make Offering" button (saffron)
- **Recent Donations:** Scrollable list (anonymized or with consent)

### Seva Logging Page
- **Log Entry Form:** Card with event selector, date, hours, role, notes
- **My Seva History:** Timeline view of past seva entries
- **Leaderboard:** Top contributors (optional, with consent)

### Admin Panel
- **Dashboard:** Grid of stat cards + charts
- **Management Tables:** Events, Donations, Books, Users
- **CRUD Forms:** Modal-based create/edit forms
- **Export Buttons:** CSV download functionality

---

## Images

**Hero Image (Homepage):**
- Large, high-quality devotional image: ISKCON temple facade, deity worship scene, or devotees in kirtan
- Semi-transparent gradient overlay (bottom to top, maroon to transparent)
- Ensure text contrast with overlay

**Event Images:**
- Photos of past events, temple activities, prasadam distribution
- Fallback: Illustrated icons for event categories

**Library/Book Covers:**
- PDF thumbnails or custom book cover designs
- Placeholder: Decorative frame with book title for PDFs without covers

**Background Patterns:**
- Subtle cream texture for page backgrounds
- Devotional motifs (lotus, peacock feather) as watermarks (very subtle, 5% opacity)

---

## Visual Enhancements

**Decorative Elements:**
- Lotus flower dividers between sections
- Om symbol as section watermarks
- Tilak/bindi accent dots in headings
- Rangoli-inspired patterns in borders

**Icons:**
- Use Heroicons for UI actions (menu, close, download)
- Custom devotional icons for categories (prasadam, kirtan, deity worship)
- Map markers, calendar, clock for event details

**Shadows & Depth:**
- Cards: shadow-md default, shadow-lg on hover
- Modals: shadow-2xl
- Buttons: shadow-sm
- No heavy shadows - keep it light and airy

**Transitions:**
- All interactive elements: transition-all duration-200
- Hover states: subtle scale or shadow changes
- No distracting animations

---

## Accessibility & Responsive Behavior

- Minimum touch target: 44x44px for mobile
- Focus states: 2px saffron outline with offset
- ARIA labels on all icon buttons
- Semantic HTML (nav, main, article, aside)
- Alt text for all images
- Color contrast: WCAG AA minimum
- Keyboard navigation fully supported
- Screen reader tested

**Mobile Breakpoints:**
- Stack all multi-column layouts to single column below md
- Hamburger menu for navigation
- Larger tap targets on mobile
- Simplified charts on small screens

---

This design system creates a reverent, accessible, and visually cohesive experience that honors ISKCON's devotional mission while providing modern functionality for community engagement.