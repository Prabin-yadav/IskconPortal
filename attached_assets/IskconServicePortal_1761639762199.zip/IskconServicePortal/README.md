# ISKCON Digital Service Portal

A devotional, lightweight platform for ISKCON centres to manage events, volunteers, donations, and a multi-language digital library. Includes a PDF reader that can translate pages into Hindi, Nepali, and other languages on demand.

## 🕉️ Features

### Event & Volunteer Management
- Public event listing with filters by date and category
- Event detail pages with Google Maps integration
- Volunteer registration system
- Admin dashboard to manage events and export volunteer lists

### Donation & Seva Tracking
- Donation form with purpose selection
- Automatic PDF receipt generation (client-side using jsPDF)
- Seva (service) hour logging for volunteers
- Admin analytics with Chart.js visualizations

### Digital Library
- Upload/download support for PDF files (Firebase Storage)
- Multi-language metadata and search
- Advanced PDF reader with pdf.js
- **Per-page translation**: Extract text from current PDF page and translate to Hindi, Nepali, or other languages

### Additional Features
- Daily Gita Verse widget with language toggle
- Firebase Authentication with role-based access (admin/volunteer)
- Multi-language UI support (English, Hindi, Nepali)
- Light/Dark theme toggle
- Fully responsive design

## 🚀 Tech Stack

- **Frontend**: React (Vite), TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Node.js + Express
- **Database**: Firebase Firestore
- **Authentication**: Firebase Auth
- **Storage**: Firebase Storage
- **PDF Processing**: pdf.js
- **Translation**: LibreTranslate API (or Google Cloud Translation)
- **Charts**: Chart.js with react-chartjs-2
- **PDF Generation**: jsPDF

## 📦 Installation

1. **Clone and install dependencies:**
   ```bash
   npm install
   ```

2. **Set up Firebase:**
   - Create a Firebase project at [Firebase Console](https://console.firebase.google.com/)
   - Enable Authentication (Email/Password)
   - Create a Firestore Database (test mode for development)
   - Enable Storage
   - Copy your Firebase config values

3. **Configure environment variables:**
   
   Add these secrets in Replit or create a `.env` file:
   ```
   VITE_FIREBASE_API_KEY=your-api-key
   VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your-project-id
   VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=your-sender-id
   VITE_FIREBASE_APP_ID=your-app-id
   ```

   See `SAMPLE_ENV.md` for detailed setup instructions.

4. **Run the application:**
   ```bash
   npm run dev
   ```

   The app will be available at `http://localhost:5000`

## 🔧 Firebase Configuration

### Firestore Security Rules

Here are basic security rules for development (adjust for production):

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /events/{eventId} {
      allow read: if true;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == "admin";
    }
    match /registrations/{regId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    match /donations/{doc} {
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == "admin";
    }
    match /sevaLogs/{logId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    match /books/{bookId} {
      allow read: if true;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == "admin";
    }
    match /verses/{verseId} {
      allow read: if true;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == "admin";
    }
  }
}
```

### Storage Rules

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /books/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null && 
        firestore.get(/databases/(default)/documents/users/$(request.auth.uid)).data.role == "admin";
    }
  }
}
```

## 📚 Usage

### First-time Setup

1. **Create an admin user:**
   - Sign up through the portal (you'll be a volunteer by default)
   - Go to Firebase Console → Firestore Database
   - Find your user document in the `users` collection
   - Change the `role` field from `"volunteer"` to `"admin"`

2. **Seed initial data** (optional):
   - Login as admin
   - Go to Admin Dashboard
   - Create a few sample events
   - Upload sample books to the library
   - Add Gita verses to the `verses` collection in Firestore

### Using the PDF Translation Feature

1. Go to the Digital Library
2. Open any PDF book
3. Navigate to the page you want to translate
4. Select source and target languages
5. Click "Translate Page"
6. The extracted text will be translated and displayed below the PDF

**Note**: Translation works only on text-based PDFs. For scanned/image PDFs, you'll see a message about OCR (not implemented by default).

## 🌐 Translation API

### LibreTranslate (Default)

The app uses LibreTranslate's public API by default, which is free but rate-limited.

### Google Cloud Translation (Recommended for Production)

For better quality and reliability:

1. Create a Google Cloud project
2. Enable Cloud Translation API
3. Create a service account and download JSON key
4. Set environment variables:
   ```
   GOOGLE_APPLICATION_CREDENTIALS=./path/to/key.json
   GOOGLE_PROJECT_ID=your-project-id
   ```

## 📱 Responsive Design

The portal is fully responsive and works on:
- Desktop (1920px and above)
- Laptop (1024px - 1919px)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🎨 Design System

- **Colors**: Saffron (#f39c12) for primary actions, Deep Maroon (#7a1f2f) for accents, Cream (#fff8ec) for backgrounds
- **Fonts**: Poppins for headings, Noto Sans for body, Noto Serif Devanagari for sacred texts
- **Theme**: Light mode (cream) and Dark mode (temple dark)

## 🔒 Security

- Firebase Authentication for secure user login
- Role-based access control (admin/volunteer)
- Firestore security rules for data protection
- Translation API calls proxied through backend to protect keys
- Environment variables for sensitive config

## 📊 Admin Features

Admins can:
- Create, edit, and delete events
- View and export donation records (CSV)
- Upload and manage library books
- Promote volunteers to admin status
- View analytics dashboards with charts

## 🙏 Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## 📄 License

This project is open source and available under the MIT License.

## 🕉️ Acknowledgments

Built with devotion for the ISKCON community. May this portal serve to spread spiritual knowledge and facilitate seva.

**Hare Krishna Hare Krishna Krishna Krishna Hare Hare**
**Hare Rama Hare Rama Rama Rama Hare Hare**
