import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { collection, getDocs, query, limit } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, BookOpen, Heart, Users } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import type { Verse } from '@shared/schema';
import { useState, useEffect } from 'react';

export default function Home() {
  const { language } = useLanguage();
  const [randomVerse, setRandomVerse] = useState<Verse | null>(null);

  const { data: verses } = useQuery<Verse[]>({
    queryKey: ['/api/verses'],
    queryFn: async () => {
      const q = query(collection(db, 'verses'), limit(10));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Verse));
    },
  });

  useEffect(() => {
    if (verses && verses.length > 0) {
      const random = verses[Math.floor(Math.random() * verses.length)];
      setRandomVerse(random);
    }
  }, [verses]);

  const getVerseText = (verse: Verse) => {
    if (language === 'hi' && verse.verseTextHi) return verse.verseTextHi;
    if (language === 'ne' && verse.verseTextNe) return verse.verseTextNe;
    return verse.verseTextEn;
  };

  const features = [
    {
      icon: Calendar,
      title: 'Events & Volunteers',
      description: 'Join as a volunteer — become an instrument of prasāda',
      href: '/events',
      testId: 'card-events',
    },
    {
      icon: Heart,
      title: 'Donations & Seva',
      description: 'Offer with love — your gift supports prasāda and seva',
      href: '/donate',
      testId: 'card-donate',
    },
    {
      icon: BookOpen,
      title: 'Digital Library',
      description: 'Scriptures & Teachings — read, reflect, and share',
      href: '/library',
      testId: 'card-library',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-accent/10 py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="text-6xl mb-6">🕉️</div>
            <h1 className="font-heading font-bold text-4xl md:text-6xl mb-6 text-primary" data-testid="text-hero-title">
              ISKCON Digital Service Portal
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground font-serif mb-8" data-testid="text-hero-subtitle">
              Om ādi-puruṣāya namaḥ — Welcome. May all work here be for devotional service.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button asChild size="lg" data-testid="button-explore-events">
                <Link href="/events">Explore Events</Link>
              </Button>
              <Button asChild size="lg" variant="outline" data-testid="button-join-volunteer">
                <Link href="/seva">Join as Volunteer</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature) => (
              <Card
                key={feature.href}
                className="hover-elevate active-elevate-2 transition-shadow cursor-pointer"
                data-testid={feature.testId}
              >
                <Link href={feature.href}>
                  <CardContent className="pt-6 pb-6 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                      <feature.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="font-heading font-semibold text-xl mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {randomVerse && (
        <section className="py-16 bg-accent/20" data-testid="section-daily-verse">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="font-heading font-semibold text-2xl md:text-3xl text-center mb-8">
              Daily Gita Verse
            </h2>
            <Card>
              <CardContent className="pt-8 pb-8">
                <p className="font-serif text-lg md:text-xl text-center leading-relaxed mb-4" data-testid="text-verse-content">
                  {getVerseText(randomVerse)}
                </p>
                <p className="text-center text-sm text-muted-foreground" data-testid="text-verse-source">
                  — {randomVerse.source}
                  {randomVerse.chapter && randomVerse.verse && ` ${randomVerse.chapter}.${randomVerse.verse}`}
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      <section className="py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Calendar, label: 'Upcoming Events', value: '12+' },
              { icon: Users, label: 'Active Volunteers', value: '250+' },
              { icon: BookOpen, label: 'Sacred Texts', value: '100+' },
              { icon: Heart, label: 'Hours of Seva', value: '5000+' },
            ].map((stat, index) => (
              <div key={index} className="text-center" data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-3">
                  <stat.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="text-3xl font-heading font-bold text-primary mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
