import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { collection, getDocs, addDoc, query, where, orderBy } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Clock, Calendar } from 'lucide-react';
import type { SevaLog, Event, InsertSevaLog } from '@shared/schema';
import { format } from 'date-fns';
import { queryClient } from '@/lib/queryClient';

export default function Seva() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    eventId: '',
    hours: '',
    role: '',
    date: new Date().toISOString().split('T')[0],
    note: '',
  });

  const { data: events } = useQuery<Event[]>({
    queryKey: ['/api/events'],
    queryFn: async () => {
      const q = query(collection(db, 'events'), orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Event));
    },
  });

  const { data: sevaLogs, isLoading } = useQuery<SevaLog[]>({
    queryKey: ['/api/seva-logs', user?.uid],
    queryFn: async () => {
      if (!user) return [];
      const q = query(
        collection(db, 'sevaLogs'),
        where('userId', '==', user.uid),
        orderBy('date', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as SevaLog));
    },
    enabled: !!user,
  });

  const logSevaMutation = useMutation({
    mutationFn: async (data: InsertSevaLog) => {
      await addDoc(collection(db, 'sevaLogs'), data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/seva-logs'] });
      toast({
        title: 'Seva logged successfully',
        description: 'Your service has been recorded.',
      });
      setFormData({
        eventId: '',
        hours: '',
        role: '',
        date: new Date().toISOString().split('T')[0],
        note: '',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to log seva',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    logSevaMutation.mutate({
      userId: user.uid,
      eventId: formData.eventId,
      hours: parseFloat(formData.hours),
      role: formData.role,
      date: formData.date,
      note: formData.note,
    });
  };

  const totalHours = sevaLogs?.reduce((sum, log) => sum + log.hours, 0) || 0;

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4" data-testid="text-page-title">
            Seva Tracking
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Log your volunteer hours and track your service contributions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="font-heading">Total Seva Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-heading font-bold text-primary" data-testid="text-total-hours">
                  {totalHours}
                </div>
                <p className="text-sm text-muted-foreground mt-1">hours of service</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-heading">Log Seva Hours</CardTitle>
                <CardDescription>Record your volunteer service</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="eventId">Event</Label>
                    <Select
                      value={formData.eventId}
                      onValueChange={(value) => setFormData({ ...formData, eventId: value })}
                      required
                    >
                      <SelectTrigger data-testid="select-event">
                        <SelectValue placeholder="Select event" />
                      </SelectTrigger>
                      <SelectContent>
                        {events?.map(event => (
                          <SelectItem key={event.id} value={event.id}>
                            {event.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      required
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      data-testid="input-date"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hours">Hours</Label>
                    <Input
                      id="hours"
                      type="number"
                      min="0.5"
                      step="0.5"
                      required
                      value={formData.hours}
                      onChange={(e) => setFormData({ ...formData, hours: e.target.value })}
                      data-testid="input-hours"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="role">Role/Activity</Label>
                    <Input
                      id="role"
                      required
                      placeholder="E.g., Food distribution, Setup"
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                      data-testid="input-role"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="note">Notes (Optional)</Label>
                    <Textarea
                      id="note"
                      placeholder="Add any additional details..."
                      value={formData.note}
                      onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                      data-testid="input-note"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={logSevaMutation.isPending}
                    data-testid="button-submit-seva"
                  >
                    {logSevaMutation.isPending ? 'Logging...' : 'Log Seva'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="font-heading">Your Seva History</CardTitle>
                <CardDescription>A record of your volunteer contributions</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="animate-pulse flex items-center gap-4 p-4 border rounded-lg">
                        <div className="h-12 w-12 bg-muted rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-muted rounded w-1/3 mb-2"></div>
                          <div className="h-3 bg-muted rounded w-1/2"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : sevaLogs && sevaLogs.length > 0 ? (
                  <div className="space-y-4" data-testid="list-seva-logs">
                    {sevaLogs.map(log => {
                      const event = events?.find(e => e.id === log.eventId);
                      return (
                        <div
                          key={log.id}
                          className="flex items-start gap-4 p-4 border rounded-lg hover-elevate"
                          data-testid={`log-seva-${log.id}`}
                        >
                          <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                            <Clock className="h-6 w-6 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <h4 className="font-heading font-semibold">
                                {event?.title || 'Unknown Event'}
                              </h4>
                              <span className="flex-shrink-0 text-lg font-semibold text-primary">
                                {log.hours}h
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{log.role}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(log.date), 'MMM dd, yyyy')}
                            </div>
                            {log.note && (
                              <p className="text-sm text-muted-foreground mt-2 italic">
                                {log.note}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12" data-testid="text-no-seva">
                    <Clock className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="font-heading font-semibold text-xl mb-2">No seva logged yet</h3>
                    <p className="text-muted-foreground">
                      Start logging your volunteer hours to track your contributions
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
