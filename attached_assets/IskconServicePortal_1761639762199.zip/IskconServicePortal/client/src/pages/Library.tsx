import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link } from 'wouter';
import { BookOpen, Download, Search } from 'lucide-react';
import type { Book } from '@shared/schema';
import { languages } from '@shared/schema';

export default function Library() {
  const [searchQuery, setSearchQuery] = useState('');
  const [languageFilter, setLanguageFilter] = useState<string>('all');

  const { data: books, isLoading } = useQuery<Book[]>({
    queryKey: ['/api/books'],
    queryFn: async () => {
      const q = query(collection(db, 'books'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Book));
    },
  });

  const filteredBooks = books?.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         book.authors.some(a => a.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesLanguage = languageFilter === 'all' || book.language === languageFilter;
    return matchesSearch && matchesLanguage;
  });

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4" data-testid="text-page-title">
            Digital Library
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Scriptures & Teachings — read, reflect, and share
          </p>
        </div>

        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1 sm:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search books and authors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-search-books"
            />
          </div>
          <Select value={languageFilter} onValueChange={setLanguageFilter}>
            <SelectTrigger className="sm:max-w-xs" data-testid="select-language-filter">
              <SelectValue placeholder="All Languages" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Languages</SelectItem>
              {Object.entries(languages).map(([code, name]) => (
                <SelectItem key={code} value={code}>{name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map(i => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-32 bg-muted rounded mb-4"></div>
                  <div className="h-6 bg-muted rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : filteredBooks && filteredBooks.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="grid-books">
            {filteredBooks.map(book => (
              <Card
                key={book.id}
                className="hover-elevate active-elevate-2 transition-shadow flex flex-col"
                data-testid={`card-book-${book.id}`}
              >
                <CardHeader className="flex-1">
                  <div className="aspect-[3/4] bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center mb-4">
                    <BookOpen className="h-16 w-16 text-primary/40" />
                  </div>
                  <CardTitle className="font-heading text-lg line-clamp-2">{book.title}</CardTitle>
                  <CardDescription className="line-clamp-2">
                    {book.authors.join(', ')}
                  </CardDescription>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="px-2 py-0.5 text-xs font-medium bg-primary/10 text-primary rounded-full">
                      {languages[book.language as keyof typeof languages] || book.language}
                    </span>
                    {book.categories.slice(0, 2).map(cat => (
                      <span key={cat} className="px-2 py-0.5 text-xs font-medium bg-accent text-accent-foreground rounded-full">
                        {cat}
                      </span>
                    ))}
                  </div>
                </CardHeader>
                <CardContent className="pt-0 space-y-2">
                  <Button asChild className="w-full" size="sm" data-testid={`button-read-${book.id}`}>
                    <Link href={`/library/${book.id}`}>
                      <BookOpen className="h-4 w-4 mr-2" />
                      Read Online
                    </Link>
                  </Button>
                  {book.downloadUrl && (
                    <Button
                      variant="outline"
                      className="w-full"
                      size="sm"
                      asChild
                      data-testid={`button-download-${book.id}`}
                    >
                      <a href={book.downloadUrl} download target="_blank" rel="noopener noreferrer">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </a>
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12" data-testid="text-no-books">
            <BookOpen className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-heading font-semibold text-xl mb-2">No books found</h3>
            <p className="text-muted-foreground">
              {searchQuery || languageFilter !== 'all'
                ? 'Try adjusting your filters'
                : 'Check back soon for new additions'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
