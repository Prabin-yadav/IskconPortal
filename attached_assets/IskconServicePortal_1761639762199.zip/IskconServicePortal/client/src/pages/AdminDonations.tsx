import { useQuery } from '@tanstack/react-query';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Download } from 'lucide-react';
import { Link } from 'wouter';
import type { Donation } from '@shared/schema';
import { format } from 'date-fns';

export default function AdminDonations() {
  const { data: donations, isLoading } = useQuery<Donation[]>({
    queryKey: ['/api/admin/donations'],
    queryFn: async () => {
      const q = query(collection(db, 'donations'), orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Donation));
    },
  });

  const totalAmount = donations?.reduce((sum, d) => sum + d.amount, 0) || 0;

  const exportToCSV = () => {
    if (!donations) return;

    const headers = ['Date', 'Donor Name', 'Email', 'Amount', 'Purpose', 'Note'];
    const rows = donations.map(d => [
      format(new Date(d.date), 'yyyy-MM-dd'),
      d.donorName,
      d.email,
      d.amount.toString(),
      d.purpose,
      d.note || '',
    ]);

    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `donations-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button variant="ghost" className="mb-6" asChild>
          <Link href="/admin">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-heading font-bold text-4xl">Donation Management</h1>
            <p className="text-lg text-muted-foreground mt-2">
              Total Donations: <span className="font-semibold text-primary">${totalAmount.toFixed(2)}</span>
            </p>
          </div>
          <Button onClick={exportToCSV} disabled={!donations || donations.length === 0} data-testid="button-export-csv">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>

        {isLoading ? (
          <div className="text-center py-12">Loading...</div>
        ) : donations && donations.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">All Donations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full" data-testid="table-donations">
                  <thead className="border-b">
                    <tr className="text-left">
                      <th className="pb-3 font-heading">Date</th>
                      <th className="pb-3 font-heading">Donor</th>
                      <th className="pb-3 font-heading">Amount</th>
                      <th className="pb-3 font-heading">Purpose</th>
                      <th className="pb-3 font-heading">Contact</th>
                    </tr>
                  </thead>
                  <tbody>
                    {donations.map(donation => (
                      <tr key={donation.id} className="border-b last:border-0" data-testid={`row-donation-${donation.id}`}>
                        <td className="py-4 text-sm">
                          {format(new Date(donation.date), 'MMM dd, yyyy')}
                        </td>
                        <td className="py-4 font-medium">{donation.donorName}</td>
                        <td className="py-4 font-semibold text-primary">${donation.amount.toFixed(2)}</td>
                        <td className="py-4 text-sm">{donation.purpose}</td>
                        <td className="py-4 text-sm text-muted-foreground">{donation.email}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No donations yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
