import { useQuery } from '@tanstack/react-query';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import {
  Calendar,
  Users,
  Heart,
  BookOpen,
  Clock,
  TrendingUp,
  Settings,
  FileText,
} from 'lucide-react';
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import type { Event, Donation, SevaLog } from '@shared/schema';

ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend);

export default function Admin() {
  const { data: events } = useQuery<Event[]>({
    queryKey: ['/api/admin/events'],
    queryFn: async () => {
      const snapshot = await getDocs(collection(db, 'events'));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Event));
    },
  });

  const { data: donations } = useQuery<Donation[]>({
    queryKey: ['/api/admin/donations'],
    queryFn: async () => {
      const snapshot = await getDocs(collection(db, 'donations'));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Donation));
    },
  });

  const { data: sevaLogs } = useQuery<SevaLog[]>({
    queryKey: ['/api/admin/seva-logs'],
    queryFn: async () => {
      const snapshot = await getDocs(collection(db, 'sevaLogs'));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as SevaLog));
    },
  });

  const totalDonations = donations?.reduce((sum, d) => sum + d.amount, 0) || 0;
  const totalSevaHours = sevaLogs?.reduce((sum, s) => sum + s.hours, 0) || 0;
  const uniqueVolunteers = new Set(sevaLogs?.map(s => s.userId)).size;

  const donationsByPurpose = donations?.reduce((acc, d) => {
    acc[d.purpose] = (acc[d.purpose] || 0) + d.amount;
    return acc;
  }, {} as Record<string, number>);

  const donationChartData = {
    labels: Object.keys(donationsByPurpose || {}),
    datasets: [{
      label: 'Donations by Purpose',
      data: Object.values(donationsByPurpose || {}),
      backgroundColor: [
        'hsl(var(--chart-1))',
        'hsl(var(--chart-2))',
        'hsl(var(--chart-3))',
        'hsl(var(--chart-4))',
        'hsl(var(--chart-5))',
      ],
    }],
  };

  const donationsByMonth = donations?.reduce((acc, d) => {
    const month = new Date(d.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    acc[month] = (acc[month] || 0) + d.amount;
    return acc;
  }, {} as Record<string, number>);

  const monthlyDonationsData = {
    labels: Object.keys(donationsByMonth || {}).slice(-6),
    datasets: [{
      label: 'Monthly Donations ($)',
      data: Object.values(donationsByMonth || {}).slice(-6),
      backgroundColor: 'hsl(var(--primary))',
    }],
  };

  const stats = [
    { icon: Calendar, label: 'Total Events', value: events?.length || 0, color: 'text-chart-1' },
    { icon: Users, label: 'Volunteers', value: uniqueVolunteers, color: 'text-chart-2' },
    { icon: Heart, label: 'Total Donations', value: `$${totalDonations.toFixed(2)}`, color: 'text-chart-3' },
    { icon: Clock, label: 'Seva Hours', value: totalSevaHours, color: 'text-chart-4' },
  ];

  const quickActions = [
    { icon: Calendar, label: 'Manage Events', href: '/admin/events', color: 'bg-chart-1/10 text-chart-1' },
    { icon: Heart, label: 'View Donations', href: '/admin/donations', color: 'bg-chart-2/10 text-chart-2' },
    { icon: BookOpen, label: 'Library Management', href: '/admin/library', color: 'bg-chart-3/10 text-chart-3' },
    { icon: Users, label: 'User Management', href: '/admin/users', color: 'bg-chart-4/10 text-chart-4' },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-2" data-testid="text-page-title">
            Admin Dashboard
          </h1>
          <p className="text-lg text-muted-foreground">
            Manage events, donations, library, and users
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.label}
                </CardTitle>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-heading font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Donations by Purpose</CardTitle>
            </CardHeader>
            <CardContent className="h-80 flex items-center justify-center">
              {donationsByPurpose && Object.keys(donationsByPurpose).length > 0 ? (
                <Doughnut
                  data={donationChartData}
                  options={{ maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }}
                />
              ) : (
                <p className="text-muted-foreground">No donation data available</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="font-heading">Monthly Donations</CardTitle>
            </CardHeader>
            <CardContent className="h-80 flex items-center justify-center">
              {donationsByMonth && Object.keys(donationsByMonth).length > 0 ? (
                <Bar
                  data={monthlyDonationsData}
                  options={{ maintainAspectRatio: false, plugins: { legend: { display: false } } }}
                />
              ) : (
                <p className="text-muted-foreground">No donation data available</p>
              )}
            </CardContent>
          </Card>
        </div>

        <div>
          <h2 className="font-heading font-semibold text-2xl mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Card
                key={index}
                className="hover-elevate active-elevate-2 transition-shadow cursor-pointer"
                data-testid={`action-${action.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Link href={action.href}>
                  <CardContent className="pt-6 pb-6 text-center">
                    <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full ${action.color} mb-3`}>
                      <action.icon className="h-6 w-6" />
                    </div>
                    <h3 className="font-heading font-semibold">{action.label}</h3>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
