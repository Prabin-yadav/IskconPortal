import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { doc, getDoc, collection, addDoc } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, MapPin, Clock, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import type { Event, InsertRegistration } from '@shared/schema';
import { format } from 'date-fns';
import { Link } from 'wouter';

export default function EventDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showForm, setShowForm] = useState(false);

  const { data: event, isLoading } = useQuery<Event>({
    queryKey: ['/api/events', id],
    queryFn: async () => {
      const docRef = doc(db, 'events', id!);
      const snapshot = await getDoc(docRef);
      if (!snapshot.exists()) throw new Error('Event not found');
      return { id: snapshot.id, ...snapshot.data() } as Event;
    },
    enabled: !!id,
  });

  const [formData, setFormData] = useState({
    name: user?.name || '',
    contact: user?.phone || user?.email || '',
    role: '',
  });

  const registerMutation = useMutation({
    mutationFn: async (data: InsertRegistration) => {
      await addDoc(collection(db, 'registrations'), {
        ...data,
        timestamp: new Date().toISOString(),
        status: 'pending',
      });
    },
    onSuccess: () => {
      toast({
        title: 'Registration successful',
        description: 'You have been registered for this event.',
      });
      setShowForm(false);
      setFormData({ name: user?.name || '', contact: user?.phone || user?.email || '', role: '' });
    },
    onError: (error: any) => {
      toast({
        title: 'Registration failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!event) return;

    registerMutation.mutate({
      eventId: event.id,
      userId: user?.uid,
      name: formData.name,
      contact: formData.contact,
      role: formData.role,
      status: 'pending',
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="mt-4 text-muted-foreground">Loading event...</p>
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-heading text-2xl mb-2">Event not found</h2>
          <Button asChild>
            <Link href="/events">Back to Events</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => setLocation('/events')}
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Events
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div>
              <div className="flex items-start justify-between gap-4 mb-4">
                <h1 className="font-heading font-bold text-4xl" data-testid="text-event-title">
                  {event.title}
                </h1>
                <span className="px-3 py-1 text-sm font-medium bg-primary/10 text-primary rounded-full">
                  {event.category}
                </span>
              </div>

              <div className="space-y-3 text-muted-foreground">
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5" />
                  <span>{format(new Date(event.date), 'EEEE, MMMM dd, yyyy')}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5" />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5" />
                  <span>{event.venue} - {event.address}</span>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="font-heading">Event Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                  {event.description}
                </p>
              </CardContent>
            </Card>

            {event.lat && event.lng && (
              <Card>
                <CardHeader>
                  <CardTitle className="font-heading">Location</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                    <iframe
                      width="100%"
                      height="100%"
                      frameBorder="0"
                      style={{ border: 0 }}
                      src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${event.lat},${event.lng}&zoom=15`}
                      allowFullScreen
                      title="Event location"
                    ></iframe>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle className="font-heading">Register as Volunteer</CardTitle>
              </CardHeader>
              <CardContent>
                {!user ? (
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-4">
                      Please sign in to register for this event
                    </p>
                    <Button asChild className="w-full" data-testid="button-login">
                      <Link href="/login">Sign In</Link>
                    </Button>
                  </div>
                ) : !showForm ? (
                  <Button
                    className="w-full"
                    onClick={() => setShowForm(true)}
                    data-testid="button-show-registration-form"
                  >
                    Register Now
                  </Button>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        data-testid="input-volunteer-name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contact">Contact (Email/Phone)</Label>
                      <Input
                        id="contact"
                        required
                        value={formData.contact}
                        onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                        data-testid="input-volunteer-contact"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="role">Volunteer Role</Label>
                      <Textarea
                        id="role"
                        required
                        placeholder="E.g., Food distribution, Setup, Cleanup, etc."
                        value={formData.role}
                        onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                        data-testid="input-volunteer-role"
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        className="flex-1"
                        onClick={() => setShowForm(false)}
                        data-testid="button-cancel"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        className="flex-1"
                        disabled={registerMutation.isPending}
                        data-testid="button-submit-registration"
                      >
                        {registerMutation.isPending ? 'Registering...' : 'Submit'}
                      </Button>
                    </div>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
