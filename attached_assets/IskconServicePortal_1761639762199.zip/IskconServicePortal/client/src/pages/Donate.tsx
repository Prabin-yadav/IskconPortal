import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Heart } from 'lucide-react';
import type { InsertDonation } from '@shared/schema';
import jsPDF from 'jspdf';

export default function Donate() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    donorName: '',
    email: '',
    phone: '',
    amount: '',
    purpose: '',
    note: '',
  });

  const purposes = [
    'Temple Construction',
    'Food Distribution (Prasāda)',
    'Education & Books',
    'Festival Celebrations',
    'General Donation',
    'Other',
  ];

  const suggestedAmounts = [10, 25, 50, 100, 500];

  const donateMutation = useMutation({
    mutationFn: async (data: InsertDonation) => {
      const docRef = await addDoc(collection(db, 'donations'), {
        ...data,
        date: new Date().toISOString(),
      });
      return docRef.id;
    },
    onSuccess: (donationId) => {
      generateReceipt(donationId);
      toast({
        title: 'Donation successful',
        description: 'Thank you for your generous contribution. Your receipt is being downloaded.',
      });
      setFormData({
        donorName: '',
        email: '',
        phone: '',
        amount: '',
        purpose: '',
        note: '',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Donation failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const generateReceipt = (donationId: string) => {
    const doc = new jsPDF();
    
    doc.setFontSize(20);
    doc.text('ISKCON Donation Receipt', 105, 20, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text(`Receipt ID: ${donationId}`, 20, 40);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 50);
    
    doc.text(`Donor Name: ${formData.donorName}`, 20, 70);
    doc.text(`Email: ${formData.email}`, 20, 80);
    if (formData.phone) doc.text(`Phone: ${formData.phone}`, 20, 90);
    
    doc.text(`Amount: $${formData.amount}`, 20, 110);
    doc.text(`Purpose: ${formData.purpose}`, 20, 120);
    if (formData.note) doc.text(`Note: ${formData.note}`, 20, 130);
    
    doc.setFontSize(10);
    doc.text('Thank you for your generous contribution to ISKCON.', 105, 160, { align: 'center' });
    doc.text('This receipt is for your records.', 105, 170, { align: 'center' });
    
    doc.save(`ISKCON-Receipt-${donationId}.pdf`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    donateMutation.mutate({
      donorName: formData.donorName,
      email: formData.email,
      phone: formData.phone,
      amount: parseFloat(formData.amount),
      purpose: formData.purpose,
      note: formData.note,
    });
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <Heart className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4" data-testid="text-page-title">
            Make a Donation
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Offer with love — your gift supports prasāda and seva
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-2xl">Donation Form</CardTitle>
            <CardDescription>
              Your contribution helps us serve the community and spread spiritual knowledge
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="donorName">Full Name *</Label>
                  <Input
                    id="donorName"
                    required
                    value={formData.donorName}
                    onChange={(e) => setFormData({ ...formData, donorName: e.target.value })}
                    data-testid="input-donor-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    data-testid="input-donor-email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  data-testid="input-donor-phone"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Donation Amount ($) *</Label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {suggestedAmounts.map(amount => (
                    <Button
                      key={amount}
                      type="button"
                      variant={formData.amount === amount.toString() ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFormData({ ...formData, amount: amount.toString() })}
                      data-testid={`button-amount-${amount}`}
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>
                <Input
                  id="amount"
                  type="number"
                  min="1"
                  step="0.01"
                  required
                  placeholder="Enter custom amount"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  data-testid="input-amount"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="purpose">Purpose *</Label>
                <Select
                  value={formData.purpose}
                  onValueChange={(value) => setFormData({ ...formData, purpose: value })}
                  required
                >
                  <SelectTrigger data-testid="select-purpose">
                    <SelectValue placeholder="Select purpose" />
                  </SelectTrigger>
                  <SelectContent>
                    {purposes.map(purpose => (
                      <SelectItem key={purpose} value={purpose}>{purpose}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="note">Note (Optional)</Label>
                <Textarea
                  id="note"
                  placeholder="Add a message or dedication..."
                  value={formData.note}
                  onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                  data-testid="input-note"
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                size="lg"
                disabled={donateMutation.isPending}
                data-testid="button-submit-donation"
              >
                {donateMutation.isPending ? 'Processing...' : 'Make Offering'}
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                A receipt will be automatically generated and downloaded after your donation.
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
