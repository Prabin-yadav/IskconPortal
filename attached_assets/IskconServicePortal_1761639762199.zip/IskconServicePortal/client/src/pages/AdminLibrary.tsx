import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/config/firebase';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';
import { Plus, Trash2, ArrowLeft, Upload } from 'lucide-react';
import { Link } from 'wouter';
import type { Book, InsertBook, LanguageCode } from '@shared/schema';
import { languages } from '@shared/schema';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function AdminLibrary() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    authors: '',
    language: 'en' as LanguageCode,
    categories: '',
    description: '',
  });

  const { data: books, isLoading } = useQuery<Book[]>({
    queryKey: ['/api/admin/books'],
    queryFn: async () => {
      const snapshot = await getDocs(collection(db, 'books'));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Book));
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: { file: File; metadata: InsertBook }) => {
      const storageRef = ref(storage, `books/${Date.now()}_${data.file.name}`);
      await uploadBytes(storageRef, data.file);
      const downloadUrl = await getDownloadURL(storageRef);
      
      await addDoc(collection(db, 'books'), {
        ...data.metadata,
        storagePath: storageRef.fullPath,
        downloadUrl,
        createdAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/books'] });
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
      toast({ title: 'Book uploaded successfully' });
      setOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: 'Upload failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await deleteDoc(doc(db, 'books', id));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/books'] });
      queryClient.invalidateQueries({ queryKey: ['/api/books'] });
      toast({ title: 'Book deleted successfully' });
    },
  });

  const resetForm = () => {
    setFormData({
      title: '',
      authors: '',
      language: 'en',
      categories: '',
      description: '',
    });
    setFile(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast({
        title: 'No file selected',
        description: 'Please select a PDF file to upload',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);
    
    const metadata: InsertBook = {
      title: formData.title,
      authors: formData.authors.split(',').map(a => a.trim()),
      language: formData.language,
      categories: formData.categories.split(',').map(c => c.trim()),
      description: formData.description,
      storagePath: '',
      uploadedBy: user?.uid || '',
    };

    uploadMutation.mutate({ file, metadata });
    setUploading(false);
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button variant="ghost" className="mb-6" asChild>
          <Link href="/admin">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>

        <div className="flex items-center justify-between mb-8">
          <h1 className="font-heading font-bold text-4xl">Library Management</h1>
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) resetForm(); }}>
            <DialogTrigger asChild>
              <Button data-testid="button-upload-book">
                <Plus className="h-4 w-4 mr-2" />
                Upload Book
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload New Book</DialogTitle>
                <DialogDescription>
                  Add a new PDF or text file to the digital library
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="file">PDF File *</Label>
                  <Input
                    id="file"
                    type="file"
                    accept=".pdf"
                    required
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                    data-testid="input-file"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    data-testid="input-title"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="authors">Authors * (comma-separated)</Label>
                  <Input
                    id="authors"
                    required
                    placeholder="e.g., Srila Prabhupada, A.C. Bhaktivedanta"
                    value={formData.authors}
                    onChange={(e) => setFormData({ ...formData, authors: e.target.value })}
                    data-testid="input-authors"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="language">Language *</Label>
                  <Select
                    value={formData.language}
                    onValueChange={(v) => setFormData({ ...formData, language: v as LanguageCode })}
                  >
                    <SelectTrigger data-testid="select-language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(languages).map(([code, name]) => (
                        <SelectItem key={code} value={code}>{name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="categories">Categories * (comma-separated)</Label>
                  <Input
                    id="categories"
                    required
                    placeholder="e.g., Bhagavad Gita, Philosophy, Scripture"
                    value={formData.categories}
                    onChange={(e) => setFormData({ ...formData, categories: e.target.value })}
                    data-testid="input-categories"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    rows={3}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    data-testid="input-description"
                  />
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => { setOpen(false); resetForm(); }}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={uploading || uploadMutation.isPending}>
                    <Upload className="h-4 w-4 mr-2" />
                    {uploading || uploadMutation.isPending ? 'Uploading...' : 'Upload Book'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="text-center py-12">Loading...</div>
        ) : books && books.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {books.map(book => (
              <Card key={book.id} data-testid={`book-${book.id}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="font-heading">{book.title}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        {book.authors.join(', ')} • {languages[book.language as keyof typeof languages]}
                      </p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {book.categories.map(cat => (
                          <span key={cat} className="px-2 py-0.5 text-xs font-medium bg-accent text-accent-foreground rounded-full">
                            {cat}
                          </span>
                        ))}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (confirm('Are you sure you want to delete this book?')) {
                          deleteMutation.mutate(book.id);
                        }
                      }}
                      data-testid={`button-delete-${book.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No books uploaded yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
