import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { doc, getDoc } from 'firebase/firestore';
import { ref, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/config/firebase';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';
import PdfReader from '@/components/PdfReader';
import type { Book } from '@shared/schema';
import { languages } from '@shared/schema';

export default function BookReader() {
  const { id } = useParams();

  const { data: book, isLoading } = useQuery<Book & { downloadUrl: string }>({
    queryKey: ['/api/books', id],
    queryFn: async () => {
      const docRef = doc(db, 'books', id!);
      const snapshot = await getDoc(docRef);
      
      if (!snapshot.exists()) throw new Error('Book not found');
      
      const bookData = { id: snapshot.id, ...snapshot.data() } as Book;
      
      const storageRef = ref(storage, bookData.storagePath);
      const downloadUrl = await getDownloadURL(storageRef);
      
      return { ...bookData, downloadUrl };
    },
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="mt-4 text-muted-foreground">Loading book...</p>
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-heading text-2xl mb-2">Book not found</h2>
          <Button asChild>
            <Link href="/library">Back to Library</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          className="mb-6"
          asChild
          data-testid="button-back"
        >
          <Link href="/library">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Library
          </Link>
        </Button>

        <div className="mb-8">
          <h1 className="font-heading font-bold text-4xl mb-2" data-testid="text-book-title">
            {book.title}
          </h1>
          <p className="text-lg text-muted-foreground mb-4">{book.authors.join(', ')}</p>
          <div className="flex flex-wrap gap-2">
            <span className="px-3 py-1 text-sm font-medium bg-primary/10 text-primary rounded-full">
              {languages[book.language as keyof typeof languages] || book.language}
            </span>
            {book.categories.map(cat => (
              <span key={cat} className="px-3 py-1 text-sm font-medium bg-accent text-accent-foreground rounded-full">
                {cat}
              </span>
            ))}
          </div>
          {book.description && (
            <p className="mt-4 text-muted-foreground leading-relaxed">{book.description}</p>
          )}
        </div>

        <PdfReader pdfUrl={book.downloadUrl} title={book.title} />
      </div>
    </div>
  );
}
