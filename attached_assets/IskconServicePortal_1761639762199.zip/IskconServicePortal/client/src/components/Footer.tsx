import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="border-t bg-card mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">About ISKCON</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              The International Society for Krishna Consciousness (ISKCON) is a spiritual movement dedicated to the practice of bhakti yoga and sharing the timeless wisdom of the Vedas.
            </p>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/events" className="text-muted-foreground hover:text-primary transition-colors">
                  Events
                </Link>
              </li>
              <li>
                <Link href="/library" className="text-muted-foreground hover:text-primary transition-colors">
                  Digital Library
                </Link>
              </li>
              <li>
                <Link href="/donate" className="text-muted-foreground hover:text-primary transition-colors">
                  Donate
                </Link>
              </li>
              <li>
                <Link href="/seva" className="text-muted-foreground hover:text-primary transition-colors">
                  Volunteer
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Email: info@iskcon.org</li>
              <li>Phone: +1 (555) 123-4567</li>
              <li>Address: 123 Krishna Road, City, State 12345</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} ISKCON Digital Service Portal. All rights reserved.</p>
          <p className="mt-2 font-serif italic">Hare Krishna Hare Krishna Krishna Krishna Hare Hare</p>
        </div>
      </div>
    </footer>
  );
}
