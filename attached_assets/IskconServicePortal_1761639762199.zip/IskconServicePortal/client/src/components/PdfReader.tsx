import { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronLeft, ChevronRight, Download, Languages, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { languages, type LanguageCode } from '@shared/schema';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface PdfReaderProps {
  pdfUrl: string;
  title: string;
}

export default function PdfReader({ pdfUrl, title }: PdfReaderProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [pageNum, setPageNum] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [sourceLang, setSourceLang] = useState<LanguageCode>('en');
  const [targetLang, setTargetLang] = useState<LanguageCode>('hi');
  const [translating, setTranslating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadPdf();
  }, [pdfUrl]);

  useEffect(() => {
    if (pdfDoc) {
      renderPage(pageNum);
    }
  }, [pdfDoc, pageNum]);

  const loadPdf = async () => {
    try {
      setLoading(true);
      const loadingTask = pdfjsLib.getDocument(pdfUrl);
      const pdf = await loadingTask.promise;
      setPdfDoc(pdf);
      setNumPages(pdf.numPages);
      setLoading(false);
    } catch (error) {
      console.error('Error loading PDF:', error);
      toast({
        title: 'Error loading PDF',
        description: 'Failed to load the PDF file. Please try downloading instead.',
        variant: 'destructive',
      });
      setLoading(false);
    }
  };

  const renderPage = async (num: number) => {
    if (!pdfDoc || !canvasRef.current) return;

    try {
      const page = await pdfDoc.getPage(num);
      const viewport = page.getViewport({ scale: 1.5 });
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (!context) return;

      canvas.height = viewport.height;
      canvas.width = viewport.width;

      const renderContext = {
        canvasContext: context,
        viewport: viewport,
      };

      await page.render(renderContext).promise;
      
      setTranslatedText(null);
    } catch (error) {
      console.error('Error rendering page:', error);
    }
  };

  const handleTranslatePage = async () => {
    if (!pdfDoc) return;

    try {
      setTranslating(true);
      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      const text = textContent.items
        .map((item: any) => item.str)
        .join(' ')
        .trim();

      if (!text) {
        toast({
          title: 'No text found',
          description: 'This page appears to be image-only. OCR is not yet implemented.',
          variant: 'destructive',
        });
        setTranslating(false);
        return;
      }

      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          sourceLang,
          targetLang,
        }),
      });

      if (!response.ok) throw new Error('Translation failed');

      const data = await response.json();
      setTranslatedText(data.translatedText);
      
      toast({
        title: 'Translation complete',
        description: `Page translated to ${languages[targetLang]}`,
      });
    } catch (error: any) {
      console.error('Translation error:', error);
      toast({
        title: 'Translation failed',
        description: error.message || 'Failed to translate the page. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setTranslating(false);
    }
  };

  const handlePrevPage = () => {
    if (pageNum > 1) setPageNum(pageNum - 1);
  };

  const handleNextPage = () => {
    if (pageNum < numPages) setPageNum(pageNum + 1);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="mt-4 text-muted-foreground">Loading PDF...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={handlePrevPage}
            disabled={pageNum <= 1}
            data-testid="button-prev-page"
            aria-label="Previous page"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <div className="text-sm font-medium" data-testid="text-page-number">
            Page {pageNum} of {numPages}
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={handleNextPage}
            disabled={pageNum >= numPages}
            data-testid="button-next-page"
            aria-label="Next page"
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select value={sourceLang} onValueChange={(v) => setSourceLang(v as LanguageCode)}>
            <SelectTrigger className="w-32" data-testid="select-source-lang">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(languages).map(([code, name]) => (
                <SelectItem key={code} value={code}>{name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <span className="text-muted-foreground">→</span>

          <Select value={targetLang} onValueChange={(v) => setTargetLang(v as LanguageCode)}>
            <SelectTrigger className="w-32" data-testid="select-target-lang">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(languages).map(([code, name]) => (
                <SelectItem key={code} value={code}>{name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            onClick={handleTranslatePage}
            disabled={translating}
            size="sm"
            data-testid="button-translate"
          >
            <Languages className="h-4 w-4 mr-2" />
            {translating ? 'Translating...' : 'Translate Page'}
          </Button>

          <Button
            variant="outline"
            size="sm"
            asChild
            data-testid="button-download"
          >
            <a href={pdfUrl} download={title}>
              <Download className="h-4 w-4 mr-2" />
              Download
            </a>
          </Button>
        </div>
      </div>

      <div className="relative">
        <div className="border rounded-lg overflow-auto bg-muted/10 flex justify-center">
          <canvas
            ref={canvasRef}
            className="max-w-full h-auto"
            data-testid="canvas-pdf"
          />
        </div>

        {translatedText && (
          <Card className="mt-6" data-testid="card-translation">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Languages className="h-5 w-5 text-primary" />
                  <h3 className="font-heading font-semibold">
                    Translation ({languages[targetLang]})
                  </h3>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setTranslatedText(null)}
                  data-testid="button-close-translation"
                  aria-label="Close translation"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="prose max-w-none">
                <p className="text-sm leading-relaxed whitespace-pre-wrap" data-testid="text-translated">
                  {translatedText}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
